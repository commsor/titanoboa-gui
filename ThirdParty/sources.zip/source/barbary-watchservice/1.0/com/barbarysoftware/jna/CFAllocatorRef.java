package com.barbarysoftware.jna;

import com.sun.jna.ptr.PointerByReference;

public class CFAllocatorRef extends PointerByReference {

}