package com.barbarysoftware.jna;

import com.sun.jna.ptr.PointerByReference;

public class CFArrayRef extends PointerByReference {

}